// Smooth scrolling for navigation links
document.querySelectorAll('nav a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Simple animation on scroll
window.addEventListener('scroll', () => {
    document.querySelectorAll('.project-card').forEach(card => {
        const position = card.getBoundingClientRect().top;
        if(position < window.innerHeight - 100) {
            card.style.opacity = '1';
        }
    });
});