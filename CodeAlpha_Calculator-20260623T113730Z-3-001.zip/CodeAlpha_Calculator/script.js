// Base64 encoded 'click' sound (Koi external link nahi, ye code ke andar hi hai)
const clickAudio = new Audio("data:audio/wav;base64,UklGRigAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA="); 

// Lekin sound ke liye, main aapko ek working URL recommend karunga:
const snd = new Audio('https://actions.google.com/sounds/v1/buttons/click.ogg');

function pC() {
    snd.currentTime = 0;
    snd.play().catch(e => console.log("Sound play error: User interaction required"));
}

const disp = document.getElementById('display');

function aD(v) {
    if(disp.value === '0' && v !== '.') disp.value = v;
    else disp.value += v;
}

function cD() { disp.value = '0'; }

function dL() {
    disp.value = disp.value.slice(0, -1);
    if(disp.value === '') disp.value = '0';
}

function calc() {
    try {
        disp.value = eval(disp.value.replace('%', '/100'));
    } catch {
        disp.value = 'Error';
    }
}